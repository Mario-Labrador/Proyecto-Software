<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contrato Exitoso</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
</head>
<body>
    <div class="container mt-5 text-center">
        <h1>¡Contrato creado exitosamente!</h1>
        <p>Ahora puedes contratar servicios con este contrato.</p>
        <a href="servicios.php" class="btn btn-primary">Volver a Mis Servicios</a>
    </div>
</body>
</html>